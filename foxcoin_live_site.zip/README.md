# FoxCoin (FOX)

Welcome to the official website of **FoxCoin**, the Ethereum-based ERC-20 token with a total supply of 1 billion tokens.

- 🌐 Live site: [https://foxcoin.live](https://foxcoin.live)
- 🦊 Add FOX to MetaMask using the button on the homepage
- 🔒 Smart contract address: `0xd9145CCE52D386f254917e481eB44e9943F39138`
